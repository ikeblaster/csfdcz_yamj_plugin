/*
 *      Copyright (c) 2004-2013 YAMJ Members
 *      http://code.google.com/p/moviejukebox/people/list
 *
 *      This file is part of the Yet Another Movie Jukebox (YAMJ).
 *
 *      The YAMJ is free software: you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation, either version 3 of the License, or
 *      any later version.
 *
 *      YAMJ is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with the YAMJ.  If not, see <http://www.gnu.org/licenses/>.
 *
 *      Web: http://code.google.com/p/moviejukebox/
 *
 */
package com.moviejukebox.model.Artwork;

import java.util.EnumSet;
import org.apache.commons.lang3.StringUtils;

public enum ArtworkType {
    // Define the lowercase equivalents of the Enum names

    Poster("poster"), // Thumbnail is a sub-type of poster
    Fanart("fanart"),
    Banner("banner"),
    ClearArt("clearart"),
    ClearLogo("clearlogo"),
    TvThumb("tvthumb"),
    SeasonThumb("seasonthumb"),
    CharacterArt("characterart"),
    MovieArt("movieart"),
    MovieLogo("movielogo"),
    MovieDisc("moviedisc"),
    VideoImage("videoimage");    // We don't store VideoImages in this artwork type as it's specific to a video file
    private String type;

    /**
     * Constructor
     *
     * @param type
     */
    private ArtworkType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    /**
     * Convert a string into an Enum type
     *
     * @param artworkType
     * @return
     * @throws IllegalArgumentException If type is not recognised
     *
     */
    public static ArtworkType fromString(String artworkTypeString) {
        if (StringUtils.isNotBlank(artworkTypeString)) {
            for (final ArtworkType artworkType : EnumSet.allOf(ArtworkType.class)) {
                if (artworkTypeString.equalsIgnoreCase(artworkType.type)) {
                    return artworkType;
                }
            }
        }
        // We've not found the type, so raise an exception
                throw new IllegalArgumentException("ArtworkType " + artworkTypeString + " does not exist.");
    }
}
